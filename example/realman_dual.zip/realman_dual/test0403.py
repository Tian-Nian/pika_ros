from Robotic_Arm.rm_robot_interface import *
import time
robot = RoboticArm(rm_thread_mode_e.RM_TRIPLE_MODE_E)
handle = robot.rm_create_robot_arm("192.168.80.18", 8080)
print ("robotic arm ID:", handle.id)

software_info = robot.rm_get_arm_software_info()
if software_info[0] == 0:
    print("\n================== Arm Software Information ==================")
    print("Arm Model: ", software_info[1]['product_version'])
    print("Algorithm Library Version: ", software_info[1]['algorithm_info']['version'])
    print("Control Layer Software Version: ", software_info[1]['ctrl_info']['version'])
    print("Dynamics Version: ", software_info[1]['dynamic_info']['model_version'])
    print("Planning Layer Software Version: ", software_info[1]['plan_info']['version'])
    print("==============================================================\n")
    state = robot.rm_get_current_arm_state()
    print(f"state: {state}")
else:
    print("\nFailed to get arm software information, Error code: ", software_info[0], "\n")

success,state = robot.rm_get_current_arm_state()
print(state)
success,state = robot.rm_get_current_arm_state()
print(state)
success,state = robot.rm_get_current_arm_state()
print(state)
success,state = robot.rm_get_current_arm_state()
print(state)
success,state = robot.rm_get_current_arm_state()
print(state)
success,state = robot.rm_get_current_arm_state()
print(state)


# position=state["pose"]
# position[0] += 0.05
# position[2] -= 0.1

# print("position:",position)

# success=robot.rm_movej_p(position,10,0,0,1)
# print(success)

# time.sleep(5)

